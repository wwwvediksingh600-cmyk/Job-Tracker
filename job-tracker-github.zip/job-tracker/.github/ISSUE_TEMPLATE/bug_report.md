---
name: Bug report
about: Report a problem with the app
title: "[Bug] "
labels: bug
---

**Describe the bug**
A clear description of what's wrong.

**Steps to reproduce**
1. Go to '...'
2. Click on '...'
3. See error

**Expected behavior**
What you expected to happen instead.

**Environment**
- OS:
- Node version:
- Postgres version:
- Browser (if frontend issue):

**Additional context**
Logs, screenshots, anything else useful.
