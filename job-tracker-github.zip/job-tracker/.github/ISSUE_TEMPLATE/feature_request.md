---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: enhancement
---

**What problem does this solve?**
A clear description of the use case.

**Proposed solution**
What you'd like to happen.

**Alternatives considered**
Any alternative solutions or features you've considered.
