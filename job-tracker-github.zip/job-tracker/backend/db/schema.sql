-- Job Application Tracker schema

CREATE TABLE IF NOT EXISTS applications (
  id            SERIAL PRIMARY KEY,
  company       VARCHAR(200) NOT NULL,
  role          VARCHAR(200) NOT NULL,
  location      VARCHAR(200),
  salary        VARCHAR(100),
  date_applied  DATE NOT NULL DEFAULT CURRENT_DATE,
  status        VARCHAR(20) NOT NULL DEFAULT 'Applied'
                CHECK (status IN ('Applied', 'Interview', 'Offer', 'Rejected')),
  job_url       VARCHAR(500),
  notes         TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_applications_date ON applications(date_applied);
CREATE INDEX IF NOT EXISTS idx_applications_company ON applications(company);

-- Keep updated_at fresh on every row update
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_applications_updated_at ON applications;
CREATE TRIGGER trg_applications_updated_at
BEFORE UPDATE ON applications
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
