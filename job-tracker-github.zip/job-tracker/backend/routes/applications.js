const express = require("express");
const pool = require("../db/pool");

const router = express.Router();

const VALID_STATUSES = ["Applied", "Interview", "Offer", "Rejected"];
const SORTABLE_COLUMNS = {
  date: "date_applied",
  status: "status",
  company: "company",
  role: "role",
  created: "created_at",
};

function badRequest(res, message) {
  return res.status(400).json({ error: message });
}

// GET /api/applications?search=&status=&sortBy=date&order=desc
router.get("/", async (req, res, next) => {
  try {
    const { search = "", status = "", sortBy = "date", order = "desc" } = req.query;

    const clauses = [];
    const params = [];

    if (search.trim()) {
      params.push(`%${search.trim()}%`);
      clauses.push(
        `(company ILIKE $${params.length} OR role ILIKE $${params.length} OR location ILIKE $${params.length})`
      );
    }

    if (status.trim()) {
      if (!VALID_STATUSES.includes(status)) {
        return badRequest(res, `status must be one of: ${VALID_STATUSES.join(", ")}`);
      }
      params.push(status);
      clauses.push(`status = $${params.length}`);
    }

    const whereSql = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";

    const sortColumn = SORTABLE_COLUMNS[sortBy] || SORTABLE_COLUMNS.date;
    const sortOrder = order.toLowerCase() === "asc" ? "ASC" : "DESC";

    const query = `
      SELECT * FROM applications
      ${whereSql}
      ORDER BY ${sortColumn} ${sortOrder}, id DESC
    `;

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/applications/stats  (dashboard summary)
// NOTE: defined before "/:id" so it isn't swallowed by the id route
router.get("/stats", async (req, res, next) => {
  try {
    const totalResult = await pool.query("SELECT COUNT(*)::int AS total FROM applications");
    const byStatusResult = await pool.query(
      "SELECT status, COUNT(*)::int AS count FROM applications GROUP BY status"
    );
    const last30Result = await pool.query(
      `SELECT COUNT(*)::int AS count FROM applications
       WHERE date_applied >= CURRENT_DATE - INTERVAL '30 days'`
    );
    const offersResult = await pool.query(
      "SELECT COUNT(*)::int AS count FROM applications WHERE status = 'Offer'"
    );

    const byStatus = { Applied: 0, Interview: 0, Offer: 0, Rejected: 0 };
    byStatusResult.rows.forEach((r) => {
      byStatus[r.status] = r.count;
    });

    const total = totalResult.rows[0].total;
    const interviewOrBetter = byStatus.Interview + byStatus.Offer + byStatus.Rejected;
    const responseRate = total > 0 ? Math.round((interviewOrBetter / total) * 100) : 0;
    const offerRate = total > 0 ? Math.round((byStatus.Offer / total) * 100) : 0;

    res.json({
      total,
      byStatus,
      last30Days: last30Result.rows[0].count,
      responseRate,
      offerRate,
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/applications/:id
router.get("/:id", async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await pool.query("SELECT * FROM applications WHERE id = $1", [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Application not found" });
    }
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

// POST /api/applications
router.post("/", async (req, res, next) => {
  try {
    const { company, role, location, salary, date_applied, status, job_url, notes } = req.body;

    if (!company || !role) {
      return badRequest(res, "company and role are required");
    }
    if (status && !VALID_STATUSES.includes(status)) {
      return badRequest(res, `status must be one of: ${VALID_STATUSES.join(", ")}`);
    }

    const result = await pool.query(
      `INSERT INTO applications (company, role, location, salary, date_applied, status, job_url, notes)
       VALUES ($1, $2, $3, $4, COALESCE($5, CURRENT_DATE), COALESCE($6, 'Applied'), $7, $8)
       RETURNING *`,
      [company, role, location || null, salary || null, date_applied || null, status || null, job_url || null, notes || null]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

// PUT /api/applications/:id
router.put("/:id", async (req, res, next) => {
  try {
    const { id } = req.params;
    const { company, role, location, salary, date_applied, status, job_url, notes } = req.body;

    if (status && !VALID_STATUSES.includes(status)) {
      return badRequest(res, `status must be one of: ${VALID_STATUSES.join(", ")}`);
    }

    const result = await pool.query(
      `UPDATE applications SET
         company = COALESCE($1, company),
         role = COALESCE($2, role),
         location = $3,
         salary = $4,
         date_applied = COALESCE($5, date_applied),
         status = COALESCE($6, status),
         job_url = $7,
         notes = $8
       WHERE id = $9
       RETURNING *`,
      [company, role, location, salary, date_applied, status, job_url, notes, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Application not found" });
    }
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/applications/:id
router.delete("/:id", async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await pool.query("DELETE FROM applications WHERE id = $1 RETURNING id", [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Application not found" });
    }
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
