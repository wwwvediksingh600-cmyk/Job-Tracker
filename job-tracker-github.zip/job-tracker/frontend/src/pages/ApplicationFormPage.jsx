import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { getApplication, createApplication, updateApplication } from "../api.js";

const EMPTY_FORM = {
  company: "",
  role: "",
  location: "",
  salary: "",
  date_applied: new Date().toISOString().slice(0, 10),
  status: "Applied",
  job_url: "",
  notes: "",
};

export default function ApplicationFormPage() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();

  const [form, setForm] = useState(EMPTY_FORM);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!isEdit) return;
    let cancelled = false;
    getApplication(id)
      .then((data) => {
        if (cancelled) return;
        setForm({
          company: data.company || "",
          role: data.role || "",
          location: data.location || "",
          salary: data.salary || "",
          date_applied: data.date_applied ? data.date_applied.slice(0, 10) : "",
          status: data.status || "Applied",
          job_url: data.job_url || "",
          notes: data.notes || "",
        });
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [id, isEdit]);

  function updateField(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.company.trim() || !form.role.trim()) {
      setError("Company and role are required.");
      return;
    }

    setSaving(true);
    setError("");
    try {
      if (isEdit) {
        await updateApplication(id, form);
        navigate(`/applications/${id}`);
      } else {
        const created = await createApplication(form);
        navigate(`/applications/${created.id}`);
      }
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  }

  if (loading) return <p className="muted">Loading...</p>;

  return (
    <div className="form-page">
      <Link to={isEdit ? `/applications/${id}` : "/applications"} className="back-link">
        ← Cancel
      </Link>

      <h1>{isEdit ? "Edit application" : "Add application"}</h1>

      {error && <p className="error">{error}</p>}

      <form onSubmit={handleSubmit} className="app-form">
        <div className="form-row">
          <label>
            Company *
            <input
              type="text"
              value={form.company}
              onChange={(e) => updateField("company", e.target.value)}
              required
            />
          </label>
          <label>
            Role *
            <input
              type="text"
              value={form.role}
              onChange={(e) => updateField("role", e.target.value)}
              required
            />
          </label>
        </div>

        <div className="form-row">
          <label>
            Location
            <input
              type="text"
              value={form.location}
              onChange={(e) => updateField("location", e.target.value)}
              placeholder="Remote, Bengaluru, etc."
            />
          </label>
          <label>
            Salary
            <input
              type="text"
              value={form.salary}
              onChange={(e) => updateField("salary", e.target.value)}
              placeholder="e.g. ₹8-12 LPA"
            />
          </label>
        </div>

        <div className="form-row">
          <label>
            Date applied
            <input
              type="date"
              value={form.date_applied}
              onChange={(e) => updateField("date_applied", e.target.value)}
            />
          </label>
          <label>
            Status
            <select value={form.status} onChange={(e) => updateField("status", e.target.value)}>
              <option value="Applied">Applied</option>
              <option value="Interview">Interview</option>
              <option value="Offer">Offer</option>
              <option value="Rejected">Rejected</option>
            </select>
          </label>
        </div>

        <label>
          Job posting URL
          <input
            type="url"
            value={form.job_url}
            onChange={(e) => updateField("job_url", e.target.value)}
            placeholder="https://..."
          />
        </label>

        <label>
          Notes
          <textarea
            value={form.notes}
            onChange={(e) => updateField("notes", e.target.value)}
            rows={4}
            placeholder="Referral contact, interview prep notes, etc."
          />
        </label>

        <div className="detail-actions">
          <button type="submit" className="btn-primary" disabled={saving}>
            {saving ? "Saving..." : isEdit ? "Save changes" : "Add application"}
          </button>
        </div>
      </form>
    </div>
  );
}
