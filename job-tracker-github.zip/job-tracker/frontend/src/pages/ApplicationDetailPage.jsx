import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { getApplication, deleteApplication } from "../api.js";
import StatusBadge from "../components/StatusBadge.jsx";

function formatDate(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export default function ApplicationDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [app, setApp] = useState(null);
  const [error, setError] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    getApplication(id)
      .then((data) => {
        if (!cancelled) setApp(data);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [id]);

  async function handleDelete() {
    if (!window.confirm(`Delete the application to ${app.company}? This can't be undone.`)) return;
    setDeleting(true);
    try {
      await deleteApplication(id);
      navigate("/applications");
    } catch (err) {
      setError(err.message);
      setDeleting(false);
    }
  }

  if (error) return <p className="error">Error: {error}</p>;
  if (!app) return <p className="muted">Loading...</p>;

  return (
    <div>
      <Link to="/applications" className="back-link">
        ← Back to applications
      </Link>

      <div className="detail-header">
        <div>
          <h1>{app.role}</h1>
          <h2 className="detail-company">{app.company}</h2>
        </div>
        <StatusBadge status={app.status} />
      </div>

      <div className="detail-grid">
        <div>
          <span className="detail-label">Location</span>
          <p>{app.location || "—"}</p>
        </div>
        <div>
          <span className="detail-label">Salary</span>
          <p>{app.salary || "—"}</p>
        </div>
        <div>
          <span className="detail-label">Date applied</span>
          <p>{formatDate(app.date_applied)}</p>
        </div>
        <div>
          <span className="detail-label">Last updated</span>
          <p>{formatDate(app.updated_at)}</p>
        </div>
      </div>

      {app.job_url && (
        <div className="detail-section">
          <span className="detail-label">Job posting</span>
          <p>
            <a href={app.job_url} target="_blank" rel="noreferrer">
              {app.job_url}
            </a>
          </p>
        </div>
      )}

      {app.notes && (
        <div className="detail-section">
          <span className="detail-label">Notes</span>
          <p className="notes">{app.notes}</p>
        </div>
      )}

      <div className="detail-actions">
        <Link to={`/applications/${id}/edit`} className="btn-primary">
          Edit
        </Link>
        <button className="btn-danger" onClick={handleDelete} disabled={deleting}>
          {deleting ? "Deleting..." : "Delete"}
        </button>
      </div>
    </div>
  );
}
