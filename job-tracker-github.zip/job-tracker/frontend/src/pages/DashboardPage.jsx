import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getStats, getApplications } from "../api.js";
import StatCard from "../components/StatCard.jsx";
import ApplicationRow from "../components/ApplicationRow.jsx";

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [recent, setRecent] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError("");
      try {
        const [statsData, appsData] = await Promise.all([
          getStats(),
          getApplications({ sortBy: "date", order: "desc" }),
        ]);
        if (!cancelled) {
          setStats(statsData);
          setRecent(appsData.slice(0, 5));
        }
      } catch (err) {
        if (!cancelled) setError(err.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <p className="muted">Loading dashboard...</p>;
  if (error) return <p className="error">Error: {error}</p>;

  const maxCount = Math.max(1, ...Object.values(stats.byStatus));

  return (
    <div>
      <div className="page-header">
        <h1>Dashboard</h1>
        <Link to="/applications/new" className="btn-primary">
          + Add application
        </Link>
      </div>

      <div className="stat-grid">
        <StatCard label="Total applications" value={stats.total} />
        <StatCard label="Last 30 days" value={stats.last30Days} />
        <StatCard label="Response rate" value={`${stats.responseRate}%`} accent="info" />
        <StatCard label="Offer rate" value={`${stats.offerRate}%`} accent="offer" />
      </div>

      <section className="panel">
        <h2>By status</h2>
        <div className="status-bars">
          {Object.entries(stats.byStatus).map(([status, count]) => (
            <div className="status-bar-row" key={status}>
              <span className="status-bar-label">{status}</span>
              <div className="status-bar-track">
                <div
                  className={`status-bar-fill fill-${status.toLowerCase()}`}
                  style={{ width: `${(count / maxCount) * 100}%` }}
                />
              </div>
              <span className="status-bar-count">{count}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="panel">
        <div className="panel-header">
          <h2>Recent applications</h2>
          <Link to="/applications">View all →</Link>
        </div>
        {recent.length === 0 ? (
          <p className="muted">No applications yet. Add your first one to get started.</p>
        ) : (
          <div className="app-list">
            {recent.map((app) => (
              <ApplicationRow key={app.id} application={app} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
