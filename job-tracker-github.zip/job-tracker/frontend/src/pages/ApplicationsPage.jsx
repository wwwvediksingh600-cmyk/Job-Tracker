import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getApplications } from "../api.js";
import FilterBar from "../components/FilterBar.jsx";
import ApplicationRow from "../components/ApplicationRow.jsx";

export default function ApplicationsPage() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filters, setFilters] = useState({ search: "", status: "", sortBy: "date", order: "desc" });

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError("");
      try {
        const data = await getApplications(filters);
        if (!cancelled) setApplications(data);
      } catch (err) {
        if (!cancelled) setError(err.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    const timeout = setTimeout(load, 250); // debounce search typing
    return () => {
      cancelled = true;
      clearTimeout(timeout);
    };
  }, [filters]);

  return (
    <div>
      <div className="page-header">
        <h1>Applications</h1>
        <Link to="/applications/new" className="btn-primary">
          + Add application
        </Link>
      </div>

      <FilterBar filters={filters} onChange={setFilters} />

      {loading && <p className="muted">Loading...</p>}
      {error && <p className="error">Error: {error}</p>}

      {!loading && !error && applications.length === 0 && (
        <p className="muted">No applications match your filters.</p>
      )}

      <div className="app-list">
        {applications.map((app) => (
          <ApplicationRow key={app.id} application={app} />
        ))}
      </div>
    </div>
  );
}
