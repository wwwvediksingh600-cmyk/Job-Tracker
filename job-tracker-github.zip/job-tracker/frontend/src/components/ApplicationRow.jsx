import { useNavigate } from "react-router-dom";
import StatusBadge from "./StatusBadge.jsx";

function formatDate(dateStr) {
  if (!dateStr) return "—";
  const d = new Date(dateStr);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function ApplicationRow({ application }) {
  const navigate = useNavigate();
  const { id, company, role, location, salary, date_applied, status } = application;

  return (
    <div className="app-row" onClick={() => navigate(`/applications/${id}`)}>
      <div className="app-row-main">
        <div className="app-row-title">
          <span className="company">{company}</span>
          <span className="role">{role}</span>
        </div>
        <div className="app-row-meta">
          {location && <span>{location}</span>}
          {salary && <span>{salary}</span>}
          <span>{formatDate(date_applied)}</span>
        </div>
      </div>
      <StatusBadge status={status} />
    </div>
  );
}
