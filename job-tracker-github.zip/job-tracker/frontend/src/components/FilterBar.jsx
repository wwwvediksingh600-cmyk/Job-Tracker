const STATUSES = ["Applied", "Interview", "Offer", "Rejected"];

export default function FilterBar({ filters, onChange }) {
  const { search, status, sortBy, order } = filters;

  return (
    <div className="filter-bar">
      <input
        type="text"
        placeholder="Search company, role, or location..."
        value={search}
        onChange={(e) => onChange({ ...filters, search: e.target.value })}
        className="filter-search"
      />

      <select value={status} onChange={(e) => onChange({ ...filters, status: e.target.value })}>
        <option value="">All statuses</option>
        {STATUSES.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>

      <select value={sortBy} onChange={(e) => onChange({ ...filters, sortBy: e.target.value })}>
        <option value="date">Sort: Date applied</option>
        <option value="status">Sort: Status</option>
        <option value="company">Sort: Company</option>
        <option value="role">Sort: Role</option>
      </select>

      <button
        type="button"
        className="btn-ghost"
        onClick={() => onChange({ ...filters, order: order === "asc" ? "desc" : "asc" })}
        title="Toggle sort order"
      >
        {order === "asc" ? "↑ Asc" : "↓ Desc"}
      </button>
    </div>
  );
}
