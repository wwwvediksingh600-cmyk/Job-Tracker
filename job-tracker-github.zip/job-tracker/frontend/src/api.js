const BASE_URL = import.meta.env.VITE_API_URL || "/api";

async function handleResponse(res) {
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data;
}

export async function getApplications({ search = "", status = "", sortBy = "date", order = "desc" } = {}) {
  const params = new URLSearchParams();
  if (search) params.set("search", search);
  if (status) params.set("status", status);
  params.set("sortBy", sortBy);
  params.set("order", order);

  const res = await fetch(`${BASE_URL}/applications?${params.toString()}`);
  return handleResponse(res);
}

export async function getApplication(id) {
  const res = await fetch(`${BASE_URL}/applications/${id}`);
  return handleResponse(res);
}

export async function getStats() {
  const res = await fetch(`${BASE_URL}/applications/stats`);
  return handleResponse(res);
}

export async function createApplication(payload) {
  const res = await fetch(`${BASE_URL}/applications`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

export async function updateApplication(id, payload) {
  const res = await fetch(`${BASE_URL}/applications/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

export async function deleteApplication(id) {
  const res = await fetch(`${BASE_URL}/applications/${id}`, { method: "DELETE" });
  return handleResponse(res);
}
